# NetflixClone
Simple Netflix Clone


Thanks to Reece Kenney for his amazing course [Create a Netflix clone from Scratch: JavaScript PHP + MySQL](https://www.udemy.com/course/netflix-clone/)
